_Student_
**High School of Telecommunications Arts and Technology**
Kaylahr0849@hstat.org

**schedule**

1.English
2.US History
3.Spanish 5
4.Trig 2
5.Physics
6.PE
7.SEP
8.Lunch
