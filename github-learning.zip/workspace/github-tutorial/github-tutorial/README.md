# GitHub Tutorial

_by **Kaylah Rodney**_

---
## Git vs. GitHub

**Git** takes snapshots of your code so later on you can go back to your code to 
 make changes. 

**Github** is an online server where you store your snapshots from Git. 



---
## Initial Setup

**Cloud 9** and **Github** are both linked meaning they work with each other.
Here are the following steps to start for making your
Github account;

1.Sign up on Github.com and filllout the following information to get started

2.Once your done making your Github profile,click on your profile icon on the top right corner of the website.

4.Click on it to show more options and then click on "settings".

5.In personal settings click on "SSH and GPG keys".

6.Click on "create new SSH key"in the greeen box.

7.The title of the SSH key should be called "Cloud 9"

8.To access this key,you will have to go to Cloud 9 and go on the C9 dashboard
(the C9 dashboard is where all your workspaces are stored).

9.You should see a gear icon right next to the workspaces, when you find it 
click on it.Once you have clicked on it,you should see the SSH keys in the left column.

10.Copy the second SSH key to your clipboard that is under "Connect to your private git repository".

11.When your finish copying, go back to Github settings where you began adding your new SSH key. Paste that key into the box. Then click "Add SSH key". 


---
## Repository Setup
To set up your repository you have to start by initializing Git. Initalizing Git 
will turn a directory into a repository. 

Initializing Git = `git init` How you get your commands

Repository = `repo` Where you store your files 

After initializing git with `git init` you will have to go to the Github website and add a new repo onto your Github profile (give it a name and fill out the other information given).Then you go back to C9 and type the command line `git clone URL` in the bash terminal to clone the repo on to C9. 


---
## Workflow & Commands
`Git init` is an important part of git workflow. It's what starts out your whole workflow process. 

Git add can be thought of as adding someone to your snapshot. It adds the file to be commited. 
 
After you `git add`, you commit your changes you made to `git push` to your github repository.  
 
 
 `git status` is one of the most important things to use frequently on Git to 
check if your files are added or not added nto the staging area, so later on 
 you can commit.this is also an optional command to view the history of the 
 things you have committed.To see which files are staged they would show up green.
 
 



---
## Rolling Back Changes



- `git checkout --filename ` = Is similar to `git reset` but instead it updates the working directory instead of the staging area.Using this command does not move the `HEAD` reference.

- `git reset head filename~1` = Unstages a file 

- `git reset --soft HEAD~1` =The soft reset just moves the HEAD but doesn't do anything else
- `git reset --hard HEAD~1` = Makes the staging area and the directory exactly matching the repo and deletes any action after that.

- `git reset HEAD~1` = Undoing uncommitted changes in a single command in Git.


