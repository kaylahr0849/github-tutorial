This is a scavenger hunt
Please follow the guided lines to start