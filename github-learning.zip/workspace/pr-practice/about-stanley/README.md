# Stanley Mei

_Student_

___
## **High School of Telecommunication Arts and Technology**

[stanleym1379@hstat.org](stanleym1379@hstat.org)


Hi, my name is Stanley Mei. I'm from Brooklyn, New York. I go to HSTAT. I am currently a Junior.

### Schedule

    1. Spanish
    2. Earth Science
    3. AP US History
    4. Gym
    5. Lunch
    6. AP Calculus
    7. SEP11
    8. English
    
### Things I enjoy doing
 * Playing games on my computer 
   * Comes from my dad 
 * Building computers
 * Riding my bike



