## Mr. Mueller's Ideal Afternoon

The best way to relax after a long day is to eat ice cream and play videogames.

The best ice cream is mint chocolate chip.